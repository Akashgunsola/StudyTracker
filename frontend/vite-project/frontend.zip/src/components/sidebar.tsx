// components/Sidebar.tsx
import { Link, useLocation } from "react-router-dom";
import { Home, Clock, Book, Calendar, GraduationCap, FlaskConical, Trophy, FolderCog, Settings } from "lucide-react";

const menuItems = [
  { name: "Dashboard", icon: <Home size={20} />, path: "/dashboard" },
  { name: "Sessions", icon: <Clock size={20} />, path: "/sessions" },
  { name: "Courses", icon: <Book size={20} />, path: "/courses" },
  { name: "Calendar", icon: <Calendar size={20} />, path: "/calendar" },
  { name: "Term", icon: <GraduationCap size={20} />, path: "/term" },
  { name: "Data Room", icon: <FlaskConical size={20} />, path: "/data-room" },
  { name: "Achievements", icon: <Trophy size={20} />, path: "/achievements" },
  { name: "Term Config.", icon: <FolderCog size={20} />, path: "/term-config" },
  { name: "Settings", icon: <Settings size={20} />, path: "/settings" },
];

const Sidebar = () => {
  const location = useLocation();

  return (
    <div className="h-screen w-60 bg-[#1C1F36] text-white flex flex-col p-4">
      <div className="mb-6 text-center font-bold text-lg flex flex-col items-center gap-1">
        🦉 <span className="text-blue-400">Athenify</span>
        <span className="text-xs text-red-500">⚠️ Trial expired!</span>
      </div>

      <div className="mb-4">
        <p className="text-sm text-gray-300">Next Steps • 5</p>
        <div className="w-full bg-gray-700 h-2 rounded-full mt-1">
          <div className="bg-green-400 h-2 rounded-full" style={{ width: "38%" }}></div>
        </div>
        <p className="text-sm mt-1">38%</p>
      </div>

      <nav className="flex-1 space-y-2 mt-4">
        {menuItems.map((item) => (
          <Link
            key={item.name}
            to={item.path}
            className={`flex items-center gap-3 px-3 py-2 rounded-md ${
              location.pathname === item.path ? "bg-blue-900 text-white font-semibold" : "hover:bg-gray-700"
            }`}
          >
            {item.icon}
            {item.name}
          </Link>
        ))}
      </nav>
    </div>
  );
};

export default Sidebar;
